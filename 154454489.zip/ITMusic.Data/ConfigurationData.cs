﻿using System;

namespace ITMusic.Data
{
    public static class ConfigurationData
    {
        public const string ConnectionString = "Server=.\\SQLEXPRESS;Database=ITMusic;Integrated Security=true";
    }
}
