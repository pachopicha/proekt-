﻿using ITMusic.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace ITMusic.Data
{
    public class ITMusicDbContext : DbContext
    {
        public ITMusicDbContext(DbContextOptions<ITMusicDbContext> options) : base(options)
        {
           
        }


        public DbSet<Song> Songs { get; set; }

        public DbSet<Playlist> Playlists { get; set; }

        public DbSet<Category> Categories { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(ConfigurationData.ConnectionString);
            }
            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}
