﻿using ITMusic.Data;
using ITMusic.Data.Models;
using ITMusic.Services.Contracts;
using System;

namespace ITMusic.Services
{
    public class CategoryService : ICategoryService
    {
        private ITMusicDbContext context;

        public CategoryService(ITMusicDbContext context)
        {
            this.context = context;
        }
        public int CreateCategory(string name)
        {
            var category = new Category() { Name = name };
            context.Categories.Add(category);
            context.SaveChanges();

            return category.Id;
        }


    }
}
