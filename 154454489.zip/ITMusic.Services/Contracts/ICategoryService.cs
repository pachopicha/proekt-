﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ITMusic.Services.Contracts
{
    public interface ICategoryService
    {
        int CreateCategory(string name);
    }
}
