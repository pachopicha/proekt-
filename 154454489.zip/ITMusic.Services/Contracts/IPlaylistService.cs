﻿using ITMusic.ViewModels.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ITMusic.Services.Contracts
{
    public interface IPlaylistService
    {

        PlaylistViewModel GetAllSongs();

        int AddToPlaylist(int id);
    }
}
