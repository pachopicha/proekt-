﻿using ITMusic.Data;
using ITMusic.Services.Contracts;
using ITMusic.ViewModels.Models;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using ITMusic.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace ITMusic.Services
{
    public class PlaylistService : IPlaylistService
    {
        private ITMusicDbContext context;

        public PlaylistService(ITMusicDbContext cont)
        {
            this.context = cont;
        }

        public int AddToPlaylist(int id)
        {
            var song = this.context.Songs.FirstOrDefault(s => s.Id == id);
            if (context.Playlists.Count() == 0)
            {
                var playlist = new Playlist();
                context.Playlists.Add(playlist);
                context.SaveChanges();
            }
            var playlistObj = context.Playlists.FirstOrDefault();

            song.PlaylistId = playlistObj.Id;
            playlistObj.Songs.Add(song);
            context.SaveChanges();

            return playlistObj.Id;
            

        }

        public PlaylistViewModel GetAllSongs()
        {
            var playlist = this.context.Playlists.Include(c => c.Songs).FirstOrDefault();

            var models = playlist.Songs.Select(s => new PlaylistSongModel()
            {
                Name = s.Name,
                Link = s.Link,
                Id = s.Id,
                
            }).ToList();

            var viewModel = new PlaylistViewModel() { Songs = models };

            return viewModel;
        }
    }
}
