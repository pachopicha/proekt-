﻿using ITMusic.Data;
using ITMusic.Data.Models;
using ITMusic.Services.Contracts;
using ITMusic.ViewModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ITMusic.Services
{
    public class SongsService : ISongsService
    {
        private ITMusicDbContext context;

        public SongsService(ITMusicDbContext context)
        {
            this.context = context;
        }
        public int CreateSong(string name, string description, string link, string category)
        {
            var categoryId = this.context.Categories.FirstOrDefault(c => c.Name == category).Id;
            var song = new Song()
            {
                Name = name,
                Description = description,
                Link = link,
                CategoryId = categoryId,
                Views = 1
            };
            context.Songs.Add(song);
            context.SaveChanges();

            return song.Id;
        }

        public AllSongsIndexViewModel GetSongs()
        {
            var models = context.Songs.Select(x => new IndexSongViewModel()
            {
                Id = x.Id,
                Name = x.Name,
                Link = x.Link,
                Description = x.Description,
                Category = x.Category.Name
            }).ToList();

            var songModel = new AllSongsIndexViewModel()
            {
                Songs = models
            };

            return songModel;
        }
    }
}
