﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ITMusic.ViewModels.Models
{
    public class AllSongsIndexViewModel
    {
       public IEnumerable<IndexSongViewModel> Songs { get; set; }
    }
}
