﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ITMusic.ViewModels.Models
{
    public class CategoryCreateViewModel
    {
        public string Name { get; set; }
    }
}
