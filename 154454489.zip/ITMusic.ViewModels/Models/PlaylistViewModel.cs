﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ITMusic.ViewModels.Models
{
    public class PlaylistViewModel
    {
        public IEnumerable<PlaylistSongModel> Songs { get; set; }
    }
}
