﻿using ITMusic.Services;
using ITMusic.Services.Contracts;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ITMusic.Controllers
{
    public class CategoriesController : Controller
    {
        private ICategoryService service;
        public CategoriesController(ICategoryService serv)
        {
            this.service = serv;
        }
        public IActionResult Create()
        {
            return this.View();
        }

        [HttpPost]
        public IActionResult Create(string name)
        {
            service.CreateCategory(name);
            return this.RedirectToAction("Index", "Home", new { area = "" });
        }
    }
}
