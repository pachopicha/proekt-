﻿using ITMusic.Services.Contracts;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ITMusic.Controllers
{
    public class PlaylistsController : Controller
    {
        private IPlaylistService service;

        public PlaylistsController(IPlaylistService service)
        {
            this.service = service;
        }
        public IActionResult PlaylistIndex()
        {
            var model = service.GetAllSongs();
            return this.View(model);
        }

      
        public IActionResult AddToPlaylist(int id)
        {
            service.AddToPlaylist(id);
            return this.RedirectToAction("PlaylistIndex", "Playlists", new { area = "" });
        }
    }
}
