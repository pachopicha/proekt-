﻿using ITMusic.Services.Contracts;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ITMusic.Controllers
{
    public class SongsController : Controller
    {
        private ISongsService service;

        public SongsController(ISongsService serv)
        {
            this.service = serv;
        }
        public IActionResult Create()
        {
           
            return this.View();
        }

        [HttpPost]
        public IActionResult Create(string name, string description, string link, string category)
        {
            this.service.CreateSong(name, description, link, category);
            return this.RedirectToAction("Index", "Home", new { area = "" });
        }
    }
}
